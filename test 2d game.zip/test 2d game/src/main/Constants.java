package main;

public class Constants {

    //transparent color
    public static final int t_red = 255, t_green = 0, t_blue =255;

}
